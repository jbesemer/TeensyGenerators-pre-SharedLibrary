#pragma once

#include <WProgram.h>

#include "Config.h"

// interface for loadable waveforms

class Loadable
{

};